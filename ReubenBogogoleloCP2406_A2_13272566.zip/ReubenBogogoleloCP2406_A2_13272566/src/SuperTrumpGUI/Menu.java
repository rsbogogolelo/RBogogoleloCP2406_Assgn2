package SuperTrumpGUI;

import javax.swing.*;

/**
 * Created by Reuben Bogogolelo on 04/10/2017.
 */
public class Menu extends JFrame {

    private JButton quitButton;
    private JButton startGameButton;
    private JButton gameRulesButton;
    private JPanel rootPanel;
    private JRadioButton a3PlayersRadioButton;
    private JRadioButton a4PlayersRadioButton;
    private JRadioButton a5PlayersRadioButton;
    public static Menu menu;

    public Menu(String title){
        super(title);
        Menu.menu =this;
        setContentPane(rootPanel);
        pack();
        setVisible(true);
        setDefaultLookAndFeelDecorated(true);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        quitButton.addActionListener(e -> {
            System.exit(1);
        });
//This explains the game rules which every player should know before playing the game
        gameRulesButton.addActionListener(e -> JOptionPane.showMessageDialog(this ," The game is designed to help players learn about the properties\n" +
                "and the use of economically significant and common rock-forming minerals.\n\n" +
                "The deck consists of 54 mineral cards and 6 “supertrump” cards.\n\n" +
                "Each mineral card includes information about the mineral such as, the generic chemical formula,\n" +
                "the classification, crystal system, the geological environment where the mineral is\n" +
                "commonly found or formed (igneous, metamorphic, sedimentary, or the mantle), as well as information in the\n" +
                "five playing categories (or trumps) of Hardness, Specific Gravity, Cleavage, Crystal Abundance, and Economic Value.\n\n" +
                "The first three trump categories relate to distinct physical properties of the mineral,\n" +
                "while last two categories rate the importance of the mineral in terms of abundance in the\n" +
                "earths' crystal (continental and oceanic) and value to modern societies.\n" +
                "\n" +
                "Number of players: 3 to 5\n" +
                "\n" +
                "Objective: To be the first player to lose all of your cards\n\n" +
                "\n" +


               "1.A dealer (randomly chosen) shuffles the cards and deals each player 8 cards.\n"+
        "Each player can look at their cards, but should not show them to other players.\n"+
        "The remaining card pack is placed face down on the table\n\n"+
        "\n"+
        "2. The player to the left of the dealer goes first by placing a mineral card on the table.\n"+
            "The player must state the mineral name, one of the five playing categories (i.e., either\n"+

        "Hardness, Specific Gravity, Cleavage, Crystal Abundance, or \n"+

        "Economic Value), and the top value of that category. For example, a player placing\n"+

        "Glaucophane, Specific Gravity. 3.2"));

        startGameButton.addActionListener(e -> {
            setVisible(false);
            new TrumpGameFunction(playerSelect());
        });

    }

    //Radio buttons designs to allow the selection of number of players to play.
    public int playerSelect(){
        if(a3PlayersRadioButton.isSelected()){
            return 3;
        }else {
            if (a4PlayersRadioButton.isSelected()) {
                return 4;
            } else {
                if (a5PlayersRadioButton.isSelected()) {
                    return 5;
                }
            }
        }
        return 3;
    }
}
