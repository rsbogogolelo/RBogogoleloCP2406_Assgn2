package SuperTrumpGUI;

/**
 * Created by Reuben Bogogolelo on 04/10/2017.
 */
//This serves as the main controller class
public class Main {

    public static void main(String[] args) {
        trumpGUI();
    }
    public static void trumpGUI(){
        new Menu("Mineral Super Trumps Game");

    }
}
