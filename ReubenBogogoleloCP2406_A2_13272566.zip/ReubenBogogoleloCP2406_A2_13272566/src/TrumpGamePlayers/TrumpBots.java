package TrumpGamePlayers;

import Cards.CardFunction;
import Cards.GamePlayCardFunction;
import Cards.TrumpGameCardFunction;
import java.util.Random;

/**
 * Created by Reuben Bogogolelo on 04/10/2017.
 */
public class TrumpBots {
    // This is going to be basic bots, they just find what can be played
    public CardFunction chooseCard(CardFunction currentCardFunction, String currentCat, Player currentPlayer) {
        if (currentCardFunction == null){
            for (CardFunction cardFunction : currentPlayer.hand){
                if (cardFunction instanceof GamePlayCardFunction){
                    return cardFunction;
                }
            }
        }
        for (CardFunction cardFunction : currentPlayer.hand) {
            if (cardFunction instanceof GamePlayCardFunction && currentCardFunction instanceof GamePlayCardFunction){
                if(cardFunction.isBetterThan((GamePlayCardFunction) currentCardFunction, currentCat)){
                    return cardFunction;
                }

            }
            else
                if (currentCardFunction instanceof TrumpGameCardFunction && cardFunction instanceof GamePlayCardFunction){
                return cardFunction;
                }

        }
        for (CardFunction cardFunction : currentPlayer.hand){
            if (cardFunction instanceof TrumpGameCardFunction){
                return cardFunction;
            }
        }
        if(currentCardFunction == null){
            System.out.println(currentPlayer.hand.size());
            throw new NullPointerException("Current card is null :(");
        }
        return currentCardFunction;
    }

    public String chooseCategory(String categories){
       String[] selectCat =  categories.split(", ");
        return selectCat[new Random().nextInt(selectCat.length)];
    }
}
