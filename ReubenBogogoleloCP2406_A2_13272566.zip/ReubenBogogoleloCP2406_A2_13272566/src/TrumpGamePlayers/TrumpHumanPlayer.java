package TrumpGamePlayers;

/**
 * Created by Reuben Bogogolelo on 04/10/2017.
 */
public class TrumpHumanPlayer extends Player {

    public PlayerType getPlayerType() {
        return PlayerType.HUMAN;
    }

    public TrumpHumanPlayer(int position) {
        super(position);
    }
}

