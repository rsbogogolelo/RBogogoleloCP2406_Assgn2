package TrumpGamePlayers;

/**
 * Created by Reuben Bogogolelo on 04/10/2017.
 */
public class BotPlay extends Player {
    public PlayerType getPlayerType() {
        return PlayerType.BOT;
    }

    public BotPlay(int position) {
        super(position);
    }
}
