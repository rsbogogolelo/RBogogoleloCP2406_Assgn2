package Cards;

/**
 * Created by Reuben Bogogolelo on 04/10/2017.
 */
public class TrumpGameCardFunction extends CardFunction {
    public String subtitle;
    public String categories;

    public TrumpGameCardFunction(String fileName, String imageName, String title, String subtitle, String categories) {
        super(fileName, imageName, title);
        this.subtitle = subtitle;
        this.categories = categories;
    }
    public String toString() {

        return ("\n |||||||||* TRUMP CARD *|||||||| \n" +"Title: "+ title +"\n\nChange trumps category to: " + categories+"\n\n<<<<<<< **************** >>>>>>>\n");
    }

    @Override
    public boolean isBetterThan(GamePlayCardFunction card, String category) {
        return true;
    }
}
