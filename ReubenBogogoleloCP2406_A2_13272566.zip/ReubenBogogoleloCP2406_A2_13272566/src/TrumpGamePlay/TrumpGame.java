package TrumpGamePlay; /**
 * Created by Reuben Bogogolelo on 04/10/2017.
 */
import Cards.CardFunction;
import Cards.TrumpDeckBuilder;
import SuperTrumpGUI.Menu;
import TrumpGamePlayers.BotPlay;
import TrumpGamePlayers.TrumpHumanPlayer;
import TrumpGamePlayers.Player;
import SuperTrumpGUI.TrumpGameFunction;

import java.util.*;
public class TrumpGame {
    private static final int INITIAL_CARD_DEAL = 8 ;
    private int numPlayers;
    private Player[] players;
    private TrumpDeckBuilder deck;
    public int yourPlayerId;
    public int randomDealer;
    public int startingPlay;

    public TrumpGame(int numPlayers, TrumpGameFunction gameW) {
        deck = new TrumpDeckBuilder();
        this.numPlayers = numPlayers;
        System.out.println("Creating New Game of  " + numPlayers +" players.........");
        selectDealer();
        new TrumpDeckBuilder();
        dealRandomCardsToPlayers();

        //Handling the game just for the user
        selectYouasPlayer();
        Player hupl = getHumanPlayer();
        showPlayer(hupl);

        //Handles Round Winners and Overall Game winners.
        Player startingPlayer = players[new Random().nextInt(players.length)];
        ArrayList<Player> playersNotWonYet = arrayToList(players);
        ArrayList<Player> playersWhoWon = new ArrayList<>();
        TrumpRound.RoundFinished roundFinished = new TrumpRound.RoundFinished(TrumpRound.findCategory(startingPlayer, "Cleavage, Crustal abundance, Economic value, Hardness, Specific gravity"), startingPlayer, TrumpRound.RoundFinishedType.STANDARD);
        while(playersNotWonYet.size() > 1){
            roundFinished =  new TrumpRound(gameW,arrayToList(playersNotWonYet.toArray(new Player[playersNotWonYet.size()])), roundFinished, deck, playersNotWonYet, playersWhoWon).beginRound();
        }
        for(Player player: playersWhoWon){
            System.out.println((playersWhoWon.indexOf(player) +1) + "Place : Player " + player.position);
        }
        TrumpGameFunction.gameW.buildWinners(playersWhoWon);
        sleependgame();
        TrumpGameFunction.gameW.gameClear();
        new Menu("New Game");

    }
    private void showPlayer(Player hupl) {
        System.out.println("You are Player "+ hupl +"\n");
    }

    private Player getHumanPlayer() {
        return players[yourPlayerId];
    }

    private void selectYouasPlayer() {
        yourPlayerId = 0;
    }

    public void selectDealer() {
        Random ran = new Random();
        randomDealer = ran.nextInt(numPlayers)+1;
        startingPlay = randomDealer+1;
        System.out.println("Player: " + randomDealer + " is the dealer"+ "\n");
    }

    public void dealRandomCardsToPlayers() {
        players = new Player[numPlayers];

        for (int i = 0; i < numPlayers; i++){
            //Change to BotPlay when done.
            players[i] = new BotPlay(i);

        }
        players[0] = new TrumpHumanPlayer(0);

        for (Player player: players) {
            ArrayList<CardFunction> cardFunctions = deck.dealCards(INITIAL_CARD_DEAL);
            player.setCard(cardFunctions);
        }
    }
    //Converts to List to be handled by the TrumpRound Class
    public ArrayList<Player> arrayToList(Player[] players){
       ArrayList<Player> newArrayList = new ArrayList<Player>();
        for (Player superTbasePlayer:players){
            newArrayList.add(superTbasePlayer);
        }
        return newArrayList;
    }

    public void sleependgame(){
        try {
            Thread.sleep(9000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
