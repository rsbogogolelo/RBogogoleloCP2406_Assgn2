package SuperTrumpGUI;

import javax.swing.*;

import Cards.CardFunction;
import TrumpGamePlayers.PlayerHandler;
import TrumpGamePlayers.Player;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import static java.awt.Color.WHITE;


/**
 * Created by Adroso360 on 9/10/2016.
 */
public class TrumpGameFunction extends JFrame {
    //Hand
    private int handSize;
    private JPanel playerGameHand = new JPanel();
    private JScrollPane handScroll = new JScrollPane(playerGameHand);
    //Other
    private JPanel gamePanel = new JPanel();
    private JLabel cCard = new JLabel();
    private JLabel cPlayer = new JLabel();
    private JLabel cCat = new JLabel();
    private JPanel catSelection = new JPanel();
    private JLabel majorStatus = new JLabel();
    private JLabel gameStatus = new JLabel();
    private JLabel catPrompt = new JLabel("Please Choose a Category: ");
    private JButton cleavage = new JButton("Cleavage");
    private JButton hardness = new JButton("Hardness");
    private JButton specGravity = new JButton("Specific Gravity");
    private JButton crystalAbundance = new JButton("Crystal Abundance");
    private  JButton ecoValue = new JButton("Economic Value");
    private JPanel winnersDisplayed = new JPanel();
    private JLabel handTitle = new JLabel("Current Hand");
    private JLabel cardTitle = new JLabel("Current Card:");
    public static TrumpGameFunction gameW;

    public TrumpGameFunction(int numPlay){
        TrumpGameFunction.gameW = this;
        // SETTING FONTS
        Font fontCat = new Font(Font.SANS_SERIF, 3, 30);
        Font fontPlay = new Font(Font.SANS_SERIF, 2, 20);
        cPlayer.setFont(fontPlay);
        cPlayer.setForeground(WHITE);
        cCat.setFont(fontCat);
        cardTitle.setFont(fontPlay);
        cCat.setForeground(WHITE);
        gameStatus.setForeground(WHITE);
        majorStatus.setForeground(WHITE);
        handTitle.setForeground(WHITE);
        cardTitle.setForeground(WHITE);


        setContentPane(gamePanel);


        //STYLING
        Color bg = new Color(73,73,73);
        gamePanel.setBackground(bg);
        gamePanel.setLayout(new BoxLayout(gamePanel, BoxLayout.Y_AXIS));
        setDefaultLookAndFeelDecorated(true);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


        //ADDING ELEMENTS
        gamePanel.add(cPlayer);
        gamePanel.add(cCat);
        gamePanel.add(majorStatus);
        gamePanel.add(gameStatus);
        gameStatus.setAlignmentX(Component.CENTER_ALIGNMENT);
        majorStatus.setAlignmentX(Component.CENTER_ALIGNMENT);
        gamePanel.add(Box.createRigidArea(new Dimension(0,20)));
        gamePanel.add(cardTitle);
        cardTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        gamePanel.add(cCard);
        catSelection.setVisible(false);
        catSelection.setLayout(new BoxLayout(catSelection, BoxLayout.X_AXIS));
        gamePanel.add(catSelection);
        catSelection.add(catPrompt);
        catSelection.add(cleavage);
        catSelection.add(hardness);
        catSelection.add(specGravity);
        catSelection.add(crystalAbundance);
        catSelection.add(ecoValue);
        //gamePanel.add(playerGameHand);
        //playerGameHand.setVisible(true);

        //TrumpGamePlayers Hand Components
        gamePanel.add(Box.createRigidArea(new Dimension(0,40)));
        gamePanel.add(handTitle);
        handTitle.setAlignmentY(Component.BOTTOM_ALIGNMENT);
        handTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        handTitle.setFont(fontPlay);
        gamePanel.add(handScroll);


        //Final Screen Components
        winnersDisplayed.setVisible(false);
        gamePanel.add(winnersDisplayed);

        //FINAL BULD and DISPLAY
        setVisible(true);
        pack();
        setSize(1300, 975);
        validate();



        //ACTION LISTERNERS for CATEGORY SELECTORS
        cleavage.addActionListener(e ->{
            PlayerHandler.playerHandler.categoryNotifier("Cleavage");

        });
        hardness.addActionListener(e ->{
            PlayerHandler.playerHandler.categoryNotifier("Hardness");

        });
        specGravity.addActionListener(e ->{
            PlayerHandler.playerHandler.categoryNotifier("Specific gravity");

        });
        crystalAbundance.addActionListener(e ->{
            PlayerHandler.playerHandler.categoryNotifier("Crystal abundance");

        });
        ecoValue.addActionListener(e ->{
            PlayerHandler.playerHandler.categoryNotifier("Economic value");

        });

        //running in background
        new Thread(() -> {
            new TrumpGamePlay.TrumpGame(numPlay, this);
        }).start();

    }

    public void displayCard(String fileName){
        cCard.setIcon(new ImageIcon(new ImageIcon("images/" + fileName).getImage().getScaledInstance((int)Math.floor(300 * 0.714), 300,  java.awt.Image.SCALE_SMOOTH)));
        cCard.setVisible(true);
        cCard.setAlignmentX(Component.CENTER_ALIGNMENT);
        invalidate();
        repaint();
    }
    public void displayPlayer(String playerName){
        cPlayer.setText("Current Player: Player " + playerName);
        cPlayer.setAlignmentX(Component.CENTER_ALIGNMENT);
        invalidate();
        repaint();
    }
    public void displayCat(String categoryName){
        cCat.setText("Current Category: " + categoryName);
        cCat.setAlignmentX(Component.CENTER_ALIGNMENT);
        invalidate();
        repaint();

    }
    public void displayCatChoice(){
        cardTitle.setVisible(false);
        handTitle.setVisible(false);
        catSelection.setVisible(true);
        gamePanel.setVisible(true);
    }
    public void hideCatChoice(){
        catSelection.setVisible(false);
        cardTitle.setVisible(true);
        handTitle.setVisible(true);
        invalidate();
        repaint();
    }
    public  void changeStatus(String status){
        gameStatus.setText(status);
        invalidate();
        repaint();
    }

    public void clearStatus(){
        gameStatus.setText("");
    }
    public  void changeMajorStatus(String status){
        gameStatus.setText(status);
        invalidate();
        repaint();
    }

    public void clearMajorStatus(){
        gameStatus.setText("");
    }

    public void handGUIGenerator(ArrayList<CardFunction> hand){
        playerGameHand.removeAll();
        handSize = hand.size();
        for (int i=0; i < handSize ;i++) {
            JButton card = new JButton();
            card.setIcon(new ImageIcon(new ImageIcon("images/" + hand.get(i).fileName).getImage().getScaledInstance((int)Math.floor(150 * 0.714), 150,  java.awt.Image.SCALE_SMOOTH)));
           // playerGameHand.add(new JButton());
            playerGameHand.add(card);
            int finalI1 = i;
            card.addActionListener(e ->{
                System.out.println(finalI1);
                PlayerHandler.playerHandler.cardNotifier(finalI1);
                playerGameHand.remove(card);
            });

            //Hover Effect
            card.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    super.mouseEntered(e);
                    card.setIcon(new ImageIcon(new ImageIcon("images/" + hand.get(finalI1).fileName).getImage().getScaledInstance((int)Math.floor(250 * 0.714), 250,  java.awt.Image.SCALE_SMOOTH)));
                }
            });
            card.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseExited(MouseEvent e) {
                    super.mouseExited(e);
                    card.setIcon(new ImageIcon(new ImageIcon("images/" + hand.get(finalI1).fileName).getImage().getScaledInstance((int)Math.floor(150 * 0.714), 150,  java.awt.Image.SCALE_SMOOTH)));

                }
            });
        }
        JButton skip = new JButton();
        skip.setIcon(new ImageIcon(new ImageIcon("images/Slide66.jpg").getImage().getScaledInstance((int)Math.floor(150 * 0.714), 150,  java.awt.Image.SCALE_SMOOTH)));
        playerGameHand.add(skip);
        skip.addActionListener(e -> {
            PlayerHandler.playerHandler.cardNotifier(handSize);
            playerGameHand.removeAll();
        });

        if (hand.size() == 0){
            handTitle.setText("You Have No Cards Left, others will continue to determine the other places");
            skip.setEnabled(false);
        }
        // Hover Effect
        skip.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                skip.setIcon(new ImageIcon(new ImageIcon("images/Slide66.jpg").getImage().getScaledInstance((int)Math.floor(250 * 0.714), 250,  java.awt.Image.SCALE_SMOOTH)));            }
        });
        skip.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                skip.setIcon(new ImageIcon(new ImageIcon("images/Slide66.jpg").getImage().getScaledInstance((int)Math.floor(150 * 0.714), 150,  java.awt.Image.SCALE_SMOOTH)));
            }
        });
        playerGameHand.setVisible(true);
        invalidate();
        repaint();
        validate();
    }

    // Handlers for the Ending of a Game
    public void buildWinners(ArrayList<Player> winnerList){
        for (int i=0; i < winnerList.size(); i++){
            int place = i +1;
            JLabel winner = new JLabel("            " + place +"st Place is Player: " + winnerList.get(i).position);
            winnersDisplayed.add(winner);
        }
        winnersDisplayed.setSize(1500, 500);
        winnersDisplayed.setVisible(true);
        invalidate();
        repaint();
        validate();

    }
    public void gameClear(){
        gamePanel.setVisible(false);
    }

}
