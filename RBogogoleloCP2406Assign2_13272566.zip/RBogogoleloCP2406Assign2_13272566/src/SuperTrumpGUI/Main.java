package SuperTrumpGUI;

/**
 * Created by Adroso360 on 5/10/2016.
 */

public class Main {

    public static void main(String[] args) {
        trumpGUI();
    }
    public static void trumpGUI(){
        new Menu("Mineral Super Trumps Game");

    }
}
