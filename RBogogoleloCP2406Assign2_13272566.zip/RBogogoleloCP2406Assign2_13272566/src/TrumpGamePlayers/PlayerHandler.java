package TrumpGamePlayers;
import Cards.CardFunction;
import Cards.GamePlayCardFunction;
import Cards.TrumpGameCardFunction;
import SuperTrumpGUI.TrumpGameFunction;

import java.util.InputMismatchException;


/**
 * Created by Adroso360 on 1/10/2016.
 */
public class PlayerHandler {
    private boolean wasInputEntered = false;
    private String categoryWasSelected = "";
    private int cardWasSelected;
    public static PlayerHandler playerHandler;

    public PlayerHandler(){
        playerHandler = this;
    }

    public String getCategory(String categories) {
        //System.out.println("\n Choose a Category: \n");
        String[] localCats = categories.split(", ");
        //handles if there is only 1 category passed in.
        if (localCats.length == 1) {
            return localCats[0];
        }
        for (int i = 0; i < localCats.length; i++) {
            System.out.println(i + " : " + localCats[i]);
        }
        //int userInput = -1;
        // SuperTrumpGUI
            TrumpGameFunction.gameW.displayCatChoice();

            while (!wasInputEntered){
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            wasInputEntered = false;
            TrumpGameFunction.gameW.hideCatChoice();
        return categoryWasSelected;
        //return localCats[userInput];
    }

    public CardFunction getCard(CardFunction currentCardFunction, String currentCat, Player currentPlayer) {
        //SuperTrumpGUI
        TrumpGameFunction.gameW.handGUIGenerator(currentPlayer.hand);
        System.out.println("\nChoose A Card: \n");
        //handles if there is only 1 category passed in.
        for (int i = 0; i < currentPlayer.hand.size(); i++) {
            System.out.println(i + " : " + currentPlayer.hand.get(i).toString());
        }
        System.out.println(currentPlayer.hand.size() + " : Don't Play A Card");
        int userInput = -1;
        while (userInput < 0 || userInput > currentPlayer.hand.size()) {
            try {
                System.out.println("Enter Your choice: ");
                //userInput = new Scanner(System.in).nextInt();
                //SuperTrumpGUI
                while (!wasInputEntered){
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                userInput = cardWasSelected;
                wasInputEntered = false;

                if (userInput == currentPlayer.hand.size()) {
                    return currentCardFunction;
                }
            } catch (InputMismatchException p2) {
                System.out.println("Please Enter Valid Number Input");
            }
            if (userInput >= 0 && userInput < currentPlayer.hand.size()) {
                if (currentCardFunction instanceof GamePlayCardFunction && !currentPlayer.hand.get(userInput).isBetterThan((GamePlayCardFunction) currentCardFunction, currentCat)) {
                    System.out.println(currentPlayer.hand.get(userInput).title + " is not better than " + currentCardFunction.title);
                    TrumpGameFunction.gameW.changeStatus("Card You Selected, Is not better than the current card.");
                    userInput = -1;
                } else if (currentCardFunction instanceof TrumpGameCardFunction) {

                    return currentPlayer.hand.get(userInput);
                }
            } else {
                System.out.println("Please choose a valid option"); // handles if user inputs greater than List
            }
        }

        //return cardWasSelected;
        return currentPlayer.hand.get(userInput);
    }

    public void categoryNotifier(String category){
        categoryWasSelected = category;
        wasInputEntered = true;
    }
    public void cardNotifier(int selectedCard){
        cardWasSelected = selectedCard;
        wasInputEntered = true;
    }
}
