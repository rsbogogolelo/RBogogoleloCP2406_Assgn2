package TrumpGamePlayers;

import Cards.CardFunction;

import java.util.ArrayList;

/**
 * Created by Adroso360 on 30/09/2016.
 */
public abstract class Player {
    public int position;
    public ArrayList<CardFunction> hand;
    public abstract PlayerType getPlayerType();


    public Player(int position){
        this.position = position;
    }
    public String toString() {
        return String.valueOf((position));
    }

    public void setCard(ArrayList<CardFunction> cardFunctions) {
        hand = cardFunctions;
    }

    public enum PlayerType{
        BOT,
        HUMAN,
    }
}
