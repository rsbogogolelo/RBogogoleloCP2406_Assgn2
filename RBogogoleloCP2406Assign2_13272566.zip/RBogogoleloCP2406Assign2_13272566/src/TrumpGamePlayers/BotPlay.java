package TrumpGamePlayers;

/**
 * Created by Adroso360 on 30/09/2016.
 */
public class BotPlay extends Player {
    public PlayerType getPlayerType() {
        return PlayerType.BOT;
    }

    public BotPlay(int position) {
        super(position);
    }
}
