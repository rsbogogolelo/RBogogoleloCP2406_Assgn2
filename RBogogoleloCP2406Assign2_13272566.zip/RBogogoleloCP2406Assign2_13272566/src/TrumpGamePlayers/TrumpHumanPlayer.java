package TrumpGamePlayers;

/**
 * Created by Adroso360 on 3/09/2016.
 */
public class TrumpHumanPlayer extends Player {

    public PlayerType getPlayerType() {
        return PlayerType.HUMAN;
    }

    public TrumpHumanPlayer(int position) {
        super(position);
    }
}

