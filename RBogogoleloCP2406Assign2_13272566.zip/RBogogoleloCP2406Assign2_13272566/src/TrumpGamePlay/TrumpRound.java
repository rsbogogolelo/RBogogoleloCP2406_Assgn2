package TrumpGamePlay;
import Cards.CardFunction;
import Cards.TrumpDeckBuilder;
import Cards.TrumpGameCardFunction;
import SuperTrumpGUI.TrumpGameFunction;
import TrumpGamePlayers.TrumpBots;
import TrumpGamePlayers.PlayerHandler;
import TrumpGamePlayers.Player;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by Adroso360 on 1/10/2016.
 */
public class TrumpRound {

    private final ArrayList<Player> players;
    private final TrumpGameFunction gameW;
    private Player currentPlayer;
    private final TrumpDeckBuilder deck;
    private final ArrayList<Player> playersNotWonYet;
    private final ArrayList<Player> playersWhoWon;
    private final String currentCat;
    private final RoundFinishedType roundFinishedType;

    public TrumpRound(TrumpGameFunction gameW, ArrayList<Player> players, RoundFinished roundFinished, TrumpDeckBuilder deck, ArrayList<Player> playersNotWonYet, ArrayList<Player> playersWhoWon) {
        this.playersNotWonYet = playersNotWonYet;
        this.playersWhoWon = playersWhoWon;
        this.players = players;
        this.currentPlayer = roundFinished.getPlayer();
        this.currentCat = roundFinished.getCat();
        this.roundFinishedType = roundFinished.getRoundFinishType();
        this.deck = deck;
        this.gameW = gameW;
    }

    public RoundFinished beginRound() {

        System.out.println("<<<<<<<<<<<<<< NEW ROUND HAS STARTED >>>>>>>>>>>>>>");
        //SuperTrumpGUI
        TrumpGameFunction.gameW.clearStatus();
        TrumpGameFunction.gameW.changeMajorStatus("A NEW ROUND HAS STARTED");
        gameW.displayPlayer(currentPlayer.toString());
        gameW.displayCat(currentCat);
        sleep();
        TrumpGameFunction.gameW.clearMajorStatus();
        CardFunction currentCardFunction = null;
        if(roundFinishedType.equals(RoundFinishedType.STANDARD)){
            currentCardFunction = findPickCard(currentPlayer, currentCat, currentCardFunction);
            //SuperTrumpGUI
            gameW.displayCard(currentCardFunction.fileName);

            System.out.println(currentPlayer.position + " played the card: " + currentCardFunction.toString());
            sleep();
            currentPlayer.hand.remove(currentCardFunction);
            didPlayerWin(currentPlayer);
        }
        //gameW.displayCard(currentCardFunction.fileName);
        //Handles current player cycle
        Collections.rotate(players, players.indexOf(currentPlayer) * -1);
        Collections.rotate(players, - 1);

        // Round Handler
        while (players.size() > 1){
            currentPlayer = players.get(0);
            gameW.displayPlayer(currentPlayer.toString());
            CardFunction oldCardFunction = currentCardFunction;
            currentCardFunction = findPickCard(currentPlayer, currentCat, currentCardFunction);
            //SuperTrumpGUI
            try {
                gameW.displayCard(currentCardFunction.fileName);
                gameW.displayPlayer(currentPlayer.toString());
                gameW.displayCat(currentCat);
            }
            catch (NullPointerException a){
                gameW.displayCard("Slide66.jpg");
            }
            if(oldCardFunction == null && currentCardFunction == null || oldCardFunction != null && currentCardFunction.equals(oldCardFunction)){
                System.out.println(currentPlayer.position + " did not play a card and is removed from the round");
                //SuperTrumpGUI
                TrumpGameFunction.gameW.changeStatus(currentPlayer.position + " did not play a card and is removed from the round");
                sleep();
                players.remove(currentPlayer);
                //Checks if the deck is empty upon drawing.

                if(deck.count() > 0)
                    currentPlayer.hand.add(deck.takeCard());
                else
                    //SuperTrumpGUI
                    TrumpGameFunction.gameW.changeStatus("The Deck Is Empty");
                    TrumpGameFunction.gameW.clearStatus();

            } else if(currentCardFunction instanceof TrumpGameCardFunction){
                System.out.println("Player: " + currentPlayer.position + " played the trump card: " + currentCardFunction.toString());
                sleep();
                currentPlayer.hand.remove(currentCardFunction);
                didPlayerWin(currentPlayer);
                Collections.rotate(players, -1);
                return new RoundFinished(findCategory(currentPlayer, ((TrumpGameCardFunction) currentCardFunction).categories), currentPlayer, RoundFinishedType.TRUMPCARD);
            } else {
                System.out.println("Player: " + currentPlayer.position + " played the card: " + currentCardFunction.toString());
                sleep();
                gameW.displayPlayer(currentPlayer.toString());
                gameW.displayCat(currentCat);
                currentPlayer.hand.remove(currentCardFunction);
                didPlayerWin(currentPlayer);
                Collections.rotate(players, -1);
            }
        }
        return new RoundFinished(findCategory(players.get(0), "Cleavage, Crustal abundance, Economic value, Hardness, Specific gravity"), players.get(0), RoundFinishedType.STANDARD);
    }

    public static class RoundFinished {
        private final String cat;
        private final Player player;
        private final RoundFinishedType roundFinishType;

        public RoundFinished(String cat, Player player, RoundFinishedType roundFinishType) {
            this.cat = cat;
            this.player = player;
            this.roundFinishType = roundFinishType;
        }

        public String getCat() {
            return cat;
        }

        public Player getPlayer() {
            return player;
        }

        public RoundFinishedType getRoundFinishType() {
            return roundFinishType;
        }
    }

    public enum RoundFinishedType {
        STANDARD,
        TRUMPCARD
    }

    private void didPlayerWin(Player currentPlayer) {
        if(currentPlayer.hand.size() == 0){
            System.out.println("Player: " + currentPlayer.position + " WON! as they have no cards!");
            if (currentPlayer.position ==0){
                TrumpGameFunction.gameW.handGUIGenerator(currentPlayer.hand);
            }
            playersNotWonYet.remove(currentPlayer);
            playersWhoWon.add(currentPlayer);
            players.remove(currentPlayer);
        }
    }

    public CardFunction findPickCard(Player currentPlayer, String currentCat, CardFunction currentCardFunction){
        if (currentPlayer.getPlayerType() == Player.PlayerType.HUMAN){
            currentCardFunction = new PlayerHandler().getCard(currentCardFunction,currentCat,currentPlayer);
        }
        else
        if (currentPlayer.getPlayerType() == Player.PlayerType.BOT){
            currentCardFunction = new TrumpBots().chooseCard(currentCardFunction, currentCat,currentPlayer);
        }
        return currentCardFunction;
    }
    public static String findCategory(Player currentPlayer, String categories){
        String currentCat = null;
        if (currentPlayer.getPlayerType() == Player.PlayerType.HUMAN){
            currentCat = new PlayerHandler().getCategory(categories);
            System.out.println("You have chosen: "+ currentCat);

        }
        else
        if (currentPlayer.getPlayerType() == Player.PlayerType.BOT) {
            currentCat = new TrumpBots().chooseCategory(categories);
            System.out.println("Player: " + currentPlayer + " Has Chosen the Category:  " + currentCat);
        }
        return currentCat;

    }
    // Adds a delay
    public void sleep(){
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
